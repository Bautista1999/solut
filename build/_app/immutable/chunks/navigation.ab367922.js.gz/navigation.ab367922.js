import{c as o}from"./singletons.023c6de5.js";const c=o("goto");export{c as g};
